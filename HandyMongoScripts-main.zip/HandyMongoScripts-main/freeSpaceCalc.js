

freeSpace = function() {
var count = 0;
var bytesInGB = 1024 * 1024 * 1024;
db = db.getSiblingDB("admin");
var dbs = db.runCommand({ "listDatabases": 1 }).databases;
dbs.forEach(function(database) {
if (database.name != "local" && database.name != "admin" && database.name != "config") {
var dbnew = db.getSiblingDB(database.name);
var cols = dbnew.getCollectionNames();
cols.forEach(function(col) {
    if(col != 'system.profile') { 
   print("Collection Name :" + col)
   var size = dbnew.getCollection(col).stats().wiredTiger["block-manager"]["file bytes available for reuse"]
   print("Space can be claimed is" + " " + size/bytesInGB)
   count += size
    }
    });
}	
	})
print("Total Space can be claimed is" + " " + count/bytesInGB)
}

freeSpace();
