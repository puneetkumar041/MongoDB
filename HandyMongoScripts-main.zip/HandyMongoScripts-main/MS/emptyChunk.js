var mergeChunkInfo = function(ns){
    var chunks = db.getSiblingDB("config").chunks.find({"ns" : ns}).sort({min:1}).noCursorTimeout(); 
    var totalChunks = 0;
    var totalMerges = 0;
    var totalMoves = 0;
    var previousChunk = {};
    var previousChunkInfo = {};
    var ChunkJustChanged = false;
 
    chunks.forEach( 
        function printChunkInfo(currentChunk) { 

        var db1 = db.getSiblingDB(currentChunk.ns.split(".")[0]) 
        var key = db.getSiblingDB("config").collections.findOne({_id:currentChunk.ns}).key; // will need this for the dataSize call
        db1.getMongo().setReadPref("secondary");
        var currentChunkInfo = db1.runCommand({datasize:currentChunk.ns, keyPattern:key, min:currentChunk.min, max:currentChunk.max, estimate:true });
        totalChunks++;
    
        if(currentChunkInfo.size == 0 && !ChunkJustChanged) {     
          if(JSON.stringify(previousChunk.max) == JSON.stringify(currentChunk.min) ) {
              if(previousChunk.shard.toString() == currentChunk.shard.toString() ) {
              print('db.runCommand( { mergeChunks: "' + currentChunk.ns.toString() + '",' + ' bounds: [ ' + JSON.stringify(previousChunk.min) + ',' + JSON.stringify(currentChunk.max) + ' ] })');
              ChunkJustChanged=true;
              totalMerges++;
            } 
            else {              
              print('db.runCommand( { moveChunk: "' + currentChunk.ns.toString() + '",' + ' bounds: [ ' + JSON.stringify(currentChunk.min) + ',' + JSON.stringify(currentChunk.max) + ' ], to: "' + previousChunk.shard.toString() + '" });');
              ChunkJustChanged=true;
              totalMoves++;            
            }
          }
          else {
            previousChunk=currentChunk;
            previousChunkInfo=currentChunkInfo;
            ChunkJustChanged=false; 
          }          
        }
        else {
          // if the current chunk is not empty or we already operated with the previous chunk let's continue with the next chunk pair
          previousChunk=currentChunk;
          previousChunkInfo=currentChunkInfo;
          ChunkJustChanged=false; 
        }
      }
    )
    print("***********Summary Chunk Information***********");
    print("Total Chunks: "+totalChunks);
    print("Total Move Commands to Run: "+totalMoves);
    print("Total Merge Commands to Run: "+totalMerges);
}

mergeChunkInfo("mydb.mycollection")

