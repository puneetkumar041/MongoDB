LongRunningOps = function(time) {
    time = time || 30;
    print("\noperations running longer than " + time + " seconds:\n");
    db.currentOp()["inprog"].forEach(function (op) {
        if(op["secs_running"]) {
            if(op["secs_running"] > time) {
                print("op '" + op["opid"] + "' running: " + op["secs_running"] + " seconds (" + parseInt(op["secs_running"]/60) + " minutes)");
                print(tojson(op));
            }
        }
    });
}

getCurrentOpStats = function() {
    intervals = [1,5,10,30]
    waitingForLock = 0;
    secsRunningStats = {};

    inProg = db.currentOp()["inprog"]
    inProg.forEach(function (op) {
        if(op["waitingForLock"]) {
            waitingForLock += 1;
        }

        if(op["secs_running"]) {
            intervals.forEach(function (interval) {
                if(op["secs_running"] > interval) {
                    secsRunningStats[interval] = secsRunningStats[interval] || 0;
                    secsRunningStats[interval] += 1;
                }
            });
        }
    });
    print("total = " + inProg.length);
    print("waitingForLock = " + waitingForLock);
    for(var i in secsRunningStats) {
        print("secs_running > " + i + " = " + secsRunningStats[i]);
    };
	print("Current Connections: " + db.serverStatus().connections.current)
}

connstats = function() {
	var out = db.getSiblingDB("admin").aggregate( [
   { $currentOp: { allUsers: true, idleConnections: true, idleSessions: true } }
  ,{$project:{
            "_id":0
           ,client:{$arrayElemAt:[ {$split:["$client",":"]}, 0 ] }
           ,curr_active:{$cond:[{$eq:["$active",true]},1,0]}
           ,curr_inactive:{$cond:[{$eq:["$active",false]},1,0]}
           }
   }
  ,{$match:{client:{$ne: null}}}
  ,{$group:{_id:"$client",curr_active:{$sum:"$curr_active"},curr_inactive:{$sum:"$curr_inactive"},total:{$sum:1}}}
  ,{$sort:{total:-1}}
] )
out.forEach(function(d) {
printjson(d)
})

}

totalIndexInfo = function() {
    var collections = db.getCollectionNames();
    print("TOTAL INDEX SIZES:");
    var results = []
    for (col in collections) {
        results.push([collections[col], Math.round(db.getCollection(collections[col]).totalIndexSize() / 1024 / 1024)]);
    }

    results = results.sort(function(a, b) {
        return b[1] - a[1];
    });

    for (res in results) {
        print(results[res][0] + ": " + results[res][1] + " MB");
    }
}

freeSpace = function() {
var count = 0;
var bytesInGB = 1024 * 1024 * 1024;
db = db.getSiblingDB("admin");
var dbs = db.runCommand({ "listDatabases": 1 }).databases;
dbs.forEach(function(database) {
if (database.name != "local" && database.name != "admin" && database.name != "config") {
var dbnew = db.getSiblingDB(database.name);
var cols = dbnew.getCollectionNames();
cols.forEach(function(col) {
    if(col != 'system.profile') {
   print("Collection Name :" + col)
   var size = dbnew.getCollection(col).stats().wiredTiger["block-manager"]["file bytes available for reuse"]
   print("Space can be claimed is" + " " + size/bytesInGB)
   count += size
    }
    });
}
	})
print("Total Space can be claimed is" + " " + count/bytesInGB)
}


function missrate(intervalMs) {
  var statsStart = db.serverStatus().wiredTiger.cache;
  var startTime = new Date();

  sleep(intervalMs);

  var endTime = new Date();
  var statsEnd = db.serverStatus().wiredTiger.cache;

  var logicalReads =
    statsEnd['pages requested from the cache'] -
    statsStart['pages requested from the cache'];
  var physicalReads =
    statsEnd['pages read into cache'] - statsStart['pages read into cache'];
  var elapsedTime = endTime - startTime;
  var missRate = physicalReads * 100 / logicalReads;
  var logicalReadRate =
    Math.round(logicalReads * 1000 * 100 / elapsedTime) / 100;
  var physicalReadRate =
    Math.round(physicalReads * 1000 * 100 / elapsedTime) / 100;
  var WTickets = db.serverStatus().wiredTiger.concurrentTransactions;

  print('Elapsed time (ms)', elapsedTime);
  print('logical Read Rate IO/s', logicalReadRate);
  print('physical Read Rate IO/s', physicalReadRate);
  print('wiredTiger miss rate', Math.round(missRate * 100) / 100);
  print("Read Tickets available: " + WTickets.read.available + "\n" + "Write Tickets available: " + WTickets.write.available);
  print("Current Connections: " + db.serverStatus().connections.current)
}

indexUsage = function() {
	
db.getCollectionNames().forEach(function(collname) {
    print(collname + "\n")
    db.getCollection(collname).aggregate([{ $indexStats: {} }]).forEach(function(x) { print(x.name+", "+x.accesses.ops+","+x.accesses.since) } )
    
})
}


