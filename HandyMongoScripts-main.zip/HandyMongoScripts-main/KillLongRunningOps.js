killLongRunningOps = function(time) {
    db.currentOp()["inprog"].forEach(function (op) {
        if(op["secs_running"]) {
            if(op["secs_running"] > time) {
                print("Killing this op (running " + op["secs_running"] + " seconds)");
                print(tojson(op))
                print("")
                db.killOp(op["opid"])
            }
        }
    });
}

killLongRunningOps(N); ////Provide value in seconds to kill any op running for greater than this value
