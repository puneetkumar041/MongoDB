// Sorts current ops so that the worst appear at the bottom where you can see them, 
// and only presents information relevant to diagnosing poor application performance
currentSum = function(){
    v = db.currentOp().inprog; 
    compare = function(a, b) { 
        if (a.secs_running < b.secs_running || a.secs_running===undefined) return -1; 
        if (a.secs_running > b.secs_running || b.secs_running===undefined) return 1; 
        return 0
    }; 
    v.sort(compare); 
    v.forEach(function(s){
        print("opid:", s.opid, "  op:", s.op, "  ns:", s.ns, "  secs:", s.secs_running, "  desc:", s.desc); 
        printjson(s.command); 
        print("-----------------------------------------------------------------");}
    );
}

currentSum();
