totalIndexInfo = function() {
    var collections = db.getCollectionNames();
    print("TOTAL INDEX SIZES:");
    var results = []
    for (col in collections) {
        results.push([collections[col], Math.round(db.getCollection(collections[col]).totalIndexSize() / 1024 / 1024)]);
    }

    results = results.sort(function(a, b) {
        return b[1] - a[1];
    });

    for (res in results) {
        print(results[res][0] + ": " + results[res][1] + " MB");
    }
}

totalIndexInfo();
