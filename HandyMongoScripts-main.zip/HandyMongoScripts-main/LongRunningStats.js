getCurrentOpStats = function() {
    intervals = [1,5,10,30]
    waitingForLock = 0;
    secsRunningStats = {};

    inProg = db.currentOp()["inprog"]
    inProg.forEach(function (op) {
        if(op["waitingForLock"]) {
            waitingForLock += 1;
        }

        if(op["secs_running"]) {
            intervals.forEach(function (interval) {
                if(op["secs_running"] > interval) {
                    secsRunningStats[interval] = secsRunningStats[interval] || 0;
                    secsRunningStats[interval] += 1;
                }
            });
        }
    });
    print("total = " + inProg.length);
    print("waitingForLock = " + waitingForLock);
    for(var i in secsRunningStats) {
        print("secs_running > " + i + " = " + secsRunningStats[i]);
    };
	print("Current Connections: " + db.serverStatus().connections.current)
}

getCurrentOpStats();   // Provides output to list long running ops with different intervals
