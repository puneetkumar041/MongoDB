//shows WT cache miss rate 

function missrate(intervalMs) {
  var statsStart = db.serverStatus().wiredTiger.cache;
  var startTime = new Date();

  sleep(intervalMs);

  var endTime = new Date();
  var statsEnd = db.serverStatus().wiredTiger.cache;

  var logicalReads =
    statsEnd['pages requested from the cache'] -
    statsStart['pages requested from the cache'];
  var physicalReads =
    statsEnd['pages read into cache'] - statsStart['pages read into cache'];
  var elapsedTime = endTime - startTime;
  var missRate = physicalReads * 100 / logicalReads;
  var logicalReadRate =
    Math.round(logicalReads * 1000 * 100 / elapsedTime) / 100;
  var physicalReadRate =
    Math.round(physicalReads * 1000 * 100 / elapsedTime) / 100;
  var WTickets = db.serverStatus().wiredTiger.concurrentTransactions;
  
  print('Elapsed time (ms)', elapsedTime);
  print('logical Read Rate IO/s', logicalReadRate);
  print('physical Read Rate IO/s', physicalReadRate);
  print('wiredTiger miss rate', Math.round(missRate * 100) / 100);
  print("Read Tickets available: " + WTickets.read.available + "\n" + "Write Tickets available: " + WTickets.write.available);
  print("Current Connections: " + db.serverStatus().connections.current)
}

missrate(ms);  //Pass time in milliseconds
