## Create similar db's and collection's on remote mongo from source 

var source = db.runCommand( { listCollections: 1.0, authorizedCollections: true, nameOnly: true } ).cursor.firstBatch // run on source
var dest = connect("host:IP/<authSource>") //URL of dest 
for(i=0;i<source.length;i++){ dest.getSiblingDB('dbname').createCollection(source[i].name)} // a loop can also be used for multiple db's


## Dump for specific ts

mongodump --port 27018 -d local -c oplog.rs --query '{"ts":{"$gt":{"$timestamp": {"i":46, "t": 1664162476}}}}' -o .

## mgenerate and poc java

java -jar POCDriver.jar -k 20 -i 10 -u 10 -b 20 -r 10 -t 5 -d 1800 mongodb://localhost:27017/
java -jar POCDriver.jar -k 20 -i 5 -u 10 -b 20 -r 10 -t 5 -d 7200 -n percona.colltest -x 2 
java -jar POCDriver.jar -d 1800 -n percona.colltest -i 1 -x 3 -a 5:1 -f 5 -l 24 -c mongodb://localhost:27017/
mgeneratejs '{"name": "$name", "age": "$age", "emails": {"$array": {"of": "$email", "number": 2}}}' -n 10000000 | mongoimport --host 127.0.0.1:27017 -d POCDB -c POCCOLL --mode insert


## Copy users and roles from source to target

var target = new Mongo("mongodb://......");

db.getSiblingDB("admin").system.roles.find().forEach(function(d) { if(d._id != "db.role") {target.getDB('admin').getCollection('system.roles').insert(d)}});

db.getSiblingDB("admin").system.users.find().forEach(function(d) { if(d._id != "db.user") { target.getDB('admin').getCollection('system.users').insert(d) }});



##
