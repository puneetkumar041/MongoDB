indexBuild = function() { db.currentOp(
    {'msg' :{ $exists: true },
     'command': { $exists: true },
      $or: [{ 'command.createIndexes': { $exists: true } },
            { 'command.reIndex': { $exists: true } },
            {'query.createIndexes': { $exists: true }},
            {'ns': '/\.system\.indexes\b/'} ] }).inprog.forEach(function(op) { print(op.msg); });
}
