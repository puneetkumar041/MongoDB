LongRunningOps = function(time) {
    time = time || 30;
    print("\noperations running longer than " + time + " seconds:\n");
    db.currentOp()["inprog"].forEach(function (op) {
        if(op["secs_running"]) {
            if(op["secs_running"] > time) {
                print("op '" + op["opid"] + "' running: " + op["secs_running"] + " seconds (" + parseInt(op["secs_running"]/60) + " minutes)");
                print(tojson(op));
            }
        }
    });
}

LongRunningOps(N);  //Pass number of seconds to find ops running for greater than this duration 
